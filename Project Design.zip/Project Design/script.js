// Load quizzes from JSON file
function loadQuizzes() {
    fetch('quizzes.json')
        .then(response => response.json())
        .then(data => {
            Object.keys(data).forEach((moduleKey, index) => {
                const quizContainerId = `quiz-${index + 1}`;
                if (document.getElementById(quizContainerId)) {
                    generateQuiz(data[moduleKey].questions, quizContainerId);
                }
            });
        })
        .catch(error => console.error('Error loading quizzes:', error));
}

// Dynamically generate quiz questions
function generateQuiz(questions, quizContainerId) {
    const quizContainer = document.getElementById(quizContainerId);
    quizContainer.innerHTML = ''; // Clear any existing content

    // Create and display each question
    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question');
        questionDiv.innerHTML = `<h4>${index + 1}. ${question.question}</h4>`;
        
        question.options.forEach(option => {
            const label = document.createElement('label');
            label.innerHTML = `<input type="radio" name="${quizContainerId}-q${index}" value="${option}"> ${option}`;
            questionDiv.appendChild(label);
            questionDiv.appendChild(document.createElement('br'));
        });
        
        quizContainer.appendChild(questionDiv);
    });

    // Add Submit button
    const submitButton = document.createElement('button');
    submitButton.textContent = 'Submit Quiz';
    submitButton.addEventListener('click', () => checkQuiz(questions, quizContainerId));
    quizContainer.appendChild(submitButton);
}

// Check and display quiz results
function checkQuiz(questions, quizContainerId) {
    const results = {};
    questions.forEach((question, index) => {
        const selectedAnswer = document.querySelector(`input[name="${quizContainerId}-q${index}"]:checked`);
        if (selectedAnswer && selectedAnswer.value === question.correctAnswer) {
            results[index] = "Correct";
        } else {
            results[index] = "Incorrect";
        }
    });
    displayProgress(quizContainerId, questions.length, results);
}

// Display saved quiz progress
function displayProgress(quizContainerId, totalQuestions, results) {
    const resultContainer = document.getElementById(`${quizContainerId}-result`);
    const quizResultsList = Object.values(results);

    if (quizResultsList.length) {
        resultContainer.textContent = 'Results: ' + quizResultsList.join(', ');
    } else {
        resultContainer.textContent = '';
    }
    
    // Update the progress bar based on completed questions
    const progressBar = document.getElementById('progress-bar');
    const correctAnswers = quizResultsList.filter(result => result === "Correct").length;
    const progress = (correctAnswers / totalQuestions) * 100;
    progressBar.style.width = progress + '%';
}

// Initialize Kotlin Playgrounds
function initializePlaygrounds() {
    for (let i = 1; i <= 12; i++) {
        const playgroundContainer = document.getElementById(`kotlin-playground-${i}`);
        if (playgroundContainer) {
            KotlinPlayground(playgroundContainer);
        }
    }
}

// Run functions on page load
window.onload = function() {
    loadQuizzes();
    initializePlaygrounds();
};
