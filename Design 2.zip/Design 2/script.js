// Load quizzes from quizzes.json file
function loadQuizzes() {
    fetch('quizzes.json')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            Object.keys(data).forEach((moduleKey, index) => {
                const quizContainerId = `quiz-${index + 1}`;
                const quizContainer = document.getElementById(quizContainerId);
                if (quizContainer) {
                    generateQuiz(data[moduleKey], quizContainerId);
                }
            });
        })
        .catch(error => console.error('Error loading quizzes:', error));
}

// Dynamically generate quiz questions
function generateQuiz(moduleData, quizContainerId) {
    const quizContainer = document.getElementById(quizContainerId);
    quizContainer.innerHTML = ''; // Clear any existing content

    moduleData.questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.classList.add('question');
        questionDiv.innerHTML = `<h4>${index + 1}. ${question.question}</h4>`;

        question.options.forEach(option => {
            const label = document.createElement('label');
            label.classList.add('option');
            label.style.color = "black"; // Default color for options
            
            const radio = document.createElement('input');
            radio.type = "radio";
            radio.name = `${quizContainerId}-q${index}`;
            radio.value = option;

            label.appendChild(radio);
            label.appendChild(document.createTextNode(` ${option}`));
            questionDiv.appendChild(label);
            questionDiv.appendChild(document.createElement('br'));
        });

        quizContainer.appendChild(questionDiv);
    });

    const submitButton = document.createElement('button');
    submitButton.textContent = 'Submit Quiz';
    submitButton.addEventListener('click', () => checkQuiz(moduleData.questions, quizContainerId));
    quizContainer.appendChild(submitButton);
}

// Check answers, display results, and save quiz score
function checkQuiz(questions, quizContainerId) {
    let correctCount = 0;

    questions.forEach((question, index) => {
        const selectedAnswer = document.querySelector(`input[name="${quizContainerId}-q${index}"]:checked`);
        const options = document.querySelectorAll(`input[name="${quizContainerId}-q${index}"]`);

        options.forEach(option => {
            const label = option.parentElement;
            if (option.value === question.correctAnswer) {
                label.style.color = "green"; // Correct answer in green
            } else {
                label.style.color = "black"; // Reset incorrect answers to black
            }
        });

        if (selectedAnswer && selectedAnswer.value === question.correctAnswer) {
            correctCount++;
        } else if (selectedAnswer) {
            selectedAnswer.parentElement.style.color = "red"; // Incorrect answer in red
        }
    });

    displayResults(quizContainerId, questions.length, correctCount);
    saveQuizScore(quizContainerId, correctCount, questions.length);
}

// Display quiz results and update progress bar
function displayResults(quizContainerId, totalQuestions, correctCount) {
    const resultContainer = document.getElementById(`${quizContainerId}-result`);
    if (resultContainer) {
        resultContainer.textContent = `Results: ${correctCount} out of ${totalQuestions} correct`;
    }

    const progressBar = document.getElementById('progress-bar');
    if (progressBar) {
        const progress = (correctCount / totalQuestions) * 100;
        progressBar.style.width = progress + '%';
        progressBar.textContent = `${Math.round(progress)}%`;
    }
}

// Save quiz score for the user
function saveQuizScore(quizContainerId, correctCount, totalQuestions) {
    const quizScore = {
        module: quizContainerId,
        score: correctCount,
        total: totalQuestions,
        date: new Date().toLocaleString()
    };

    // Here you could save to localStorage, a database, or a backend.
    console.log("User Quiz Score Saved:", quizScore);
}

// Initialize Kotlin Playgrounds for code snippets (optional)
function initializePlaygrounds() {
    for (let i = 1; i <= 12; i++) {
        const playgroundContainer = document.getElementById(`kotlin-playground-${i}`);
        if (playgroundContainer) {
            KotlinPlayground(playgroundContainer);
        }
    }
}

// Run functions on page load
window.onload = function() {
    loadQuizzes();
    initializePlaygrounds();
};
